Arduino 1.0 libraries for Rainbowduino.
**************************************************

Change the 33th line in Rainbowduino.h "#include <WProgram.h>" to "#include <Arduino.h>"


15/2/2012 by Frankie at Seeedstuio.
www.seeedstudio.com
**************************************************