Suli for JN516x
===
Developed within Mesh Bee firmware project:

**http://seeed-studio.github.io/Mesh_Bee/**

#####Download:
suli.h: https://github.com/Seeed-Studio/Mesh_Bee/raw/master/suli/suli.h

suli.c: https://github.com/Seeed-Studio/Mesh_Bee/raw/master/suli/suli.c


[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/Suli_JN516x)](https://github.com/igrigorik/ga-beacon)
