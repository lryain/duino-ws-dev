// RightHandRule.h: interface for the RightHandRule class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RIGHTHANDRULE_H__CF0F2EF6_D8B4_4551_91F0_9CEB14EBAE08__INCLUDED_)
#define AFX_RIGHTHANDRULE_H__CF0F2EF6_D8B4_4551_91F0_9CEB14EBAE08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class RightHandRule  
{
public:
	RightHandRule();
	virtual ~RightHandRule();

};

#endif // !defined(AFX_RIGHTHANDRULE_H__CF0F2EF6_D8B4_4551_91F0_9CEB14EBAE08__INCLUDED_)
