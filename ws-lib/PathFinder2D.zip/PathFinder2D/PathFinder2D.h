#if !defined(H_PATHFINDER2D)
#define H_PATHFINDER2D

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif
