// DFS.h: interface for the DFS class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(H_DFS)
#define H_DFS

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DFS  
{
public:
	DFS();
	virtual ~DFS();

};

#endif
