// DStar.h: interface for the DStar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSTAR_H__4F78A109_1C17_4135_9AAA_E9C583788AF1__INCLUDED_)
#define AFX_DSTAR_H__4F78A109_1C17_4135_9AAA_E9C583788AF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DStar  
{
public:
	DStar();
	virtual ~DStar();

};

#endif // !defined(AFX_DSTAR_H__4F78A109_1C17_4135_9AAA_E9C583788AF1__INCLUDED_)
