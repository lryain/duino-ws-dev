# Balanduino hardware add-on
#### Developed by Kristian Lauszus, TKJ Electronics 2013

The code is released under the GNU General Public License.
_________

Taken from Lauszus's other Github repository: <http://lauszus.github.com/Sanguino>.

For more information see the following site: <http://www.arduino.cc/en/Guide/Environment#thirdpartyhardware> or send us an email at <mail@tkjelectronics.com>.