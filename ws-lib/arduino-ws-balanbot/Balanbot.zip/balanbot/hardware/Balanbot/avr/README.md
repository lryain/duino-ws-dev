#### Developed by Kristian Lauszus, TKJ Electronics 2013

The code is released under the GNU General Public License.
_________

This makes sure that the hardware add-on can be used with the Arduino IDE 1.5.x.

For more information see the following sites: <http://www.arduino.cc/en/Guide/Environment#thirdpartyhardware>, <http://code.google.com/p/arduino/wiki/Platforms1>, and <https://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5---3rd-party-Hardware-specification> or send us an email at <mail@tkjelectronics.com>.