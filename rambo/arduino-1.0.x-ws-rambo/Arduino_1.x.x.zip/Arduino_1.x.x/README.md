To access the extra pins in EXT-2 header:  

Install the arduino software IDE/toolset 1.x.x http://www.arduino.cc/en/Main/Software  

Current recommended is Arduino version 1.0.5
The rambo directory here needs to be copied to the arduino environment in the hardware folder. You should end with a boards.txt file at arduino-1.0.5/hardware/rambo/boards.txt  
